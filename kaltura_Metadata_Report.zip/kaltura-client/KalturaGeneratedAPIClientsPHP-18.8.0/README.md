# PHP auto generated clients libs which will then be built and test by Travis CI
#### Please note that you should not make pull requests to the repo as the clientlibs are auto generated upon every Core release.
#### Instead, please submit pulls to:

https://github.com/kaltura/clients-generator
code is under sources/php5

#### Also, note that we have 2 additional PHP clients libs: generator/sources/php53, generator/sources/zend so your changes may be relevant to them too.

[![Build Status](https://travis-ci.org/kaltura/KalturaGeneratedAPIClientsPHP.svg?branch=master)](https://travis-ci.org/kaltura/KalturaGeneratedAPIClientsPHP)

