Kaltura PHP 5 API Client Library.
Compatible with Kaltura server version 18.8.0 and above.
