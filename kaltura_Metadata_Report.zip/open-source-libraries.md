# Open Source & 3rd-party components in this project
* [PHP-Excel](https://code.google.com/archive/p/php-excel/): [MIT License](https://opensource.org/licenses/mit-license.php)
* [Kaltura PHP API Client Library](https://github.com/kaltura/KalturaGeneratedAPIClientsPHP53): [AGPL v3](https://opensource.org/licenses/AGPL-3.0)